package student;

import oplossing.Person;

public class Persoon implements Person {

}
