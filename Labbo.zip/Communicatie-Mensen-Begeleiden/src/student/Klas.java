package student;

public class Klas {

}
