package oplossing;


public interface Person {

}
